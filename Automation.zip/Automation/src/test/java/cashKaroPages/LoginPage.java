package cashKaroPages;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import org.apache.commons.io.FileUtils;  
import java.util.Base64;
import java.util.Set;

import javax.imageio.ImageIO;

import org.bytedeco.javacpp.BytePointer;
import org.bytedeco.javacpp.lept;
import org.bytedeco.javacpp.lept.PIX;
import org.bytedeco.javacpp.tesseract.TessBaseAPI;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {

	WebDriver driver;

	public LoginPage(WebDriver driver) {

		this.driver = driver;

	}

	By joinFree = By.xpath(".//*[contains(@id,'link_join')]");

	By name = By.xpath(".//*[contains(@id,'firstname')]");

	By email = By.xpath(".//form/*[contains(@id,'email')]");

	By password = By.xpath(".//form/*[contains(@id,'pwd-txt')]");

	By mobileNo = By.xpath(".//div/*[contains(@id,'mobile_number')]");

	By joinWithEmail = By.xpath(".//*[contains(@id,'join_free_submit')]");

	By securityImg = By.xpath(".//*[contains(@id,'security_image')]");
	
	By enterValidNumber = By.xpath(".//div/*[contains(@id,'to_be_check')]");
	
	By facebookLink = By.xpath(".//a[contains(@id,'close_and_go_fb')]");
	
	By facebookEmail = By.xpath("//input[contains(@id,'email')]");
	
	By facebookPass = By.xpath("//input[contains(@id,'pass')]");
	
	By facebookLogin = By.xpath(".//*[contains(@id,'u_0_0')]");
	
	By close = By.xpath("//button[contains(@id,'cboxClose')]");
	
	

	public void clickOnJoinFree() throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(joinFree))).click();
		Thread.sleep(3000);

	}

	public void enterName(String userName) {

		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(name))).sendKeys(userName);

	}

	public void enterEmail(String userEmail) throws InterruptedException {

		WebElement emails=driver.findElement(email);
		emails.click();
		emails.clear();
		emails.sendKeys(userEmail);

	}

	public void enterPassword(String userPassword) throws InterruptedException {

		WebElement pwd=driver.findElement(password);
		pwd.click();
		driver.findElement(By.xpath(".//input[contains(@id,'password')]")).click();
		driver.findElement(By.xpath(".//input[contains(@id,'password')]")).clear();
		driver.findElement(By.xpath(".//input[contains(@id,'password')]")).sendKeys(userPassword);
	}

	public void enterMobile(String userMobile) throws InterruptedException {

		WebElement mobileNum=driver.findElement(mobileNo);
		mobileNum.click();
		driver.findElement(By.xpath(".//div/input[contains(@name,'mobile_number')]")).click();
		driver.findElement(By.xpath(".//div/input[contains(@name,'mobile_number')]")).clear();
		driver.findElement(By.xpath(".//div/input[contains(@name,'mobile_number')]")).sendKeys(userMobile);
		
	}

	
	public void securityImg() throws IOException, InterruptedException {

		/*
		 * WebElement img =
		 * driver.findElement(By.xpath(".//*[contains(@id,'security_image')]")); String
		 * src = img.getAttribute("src"); System.out.println(src);
		 * 
		 * URL imageURL = new URL(src); BufferedImage saveImage =
		 * ImageIO.read(imageURL); ImageIO.write(saveImage, "png", new
		 * File("C:\\Users\\Mahi\\Selenium\\Automation\\img.png"));
		 * 
		 * TessBaseAPI instance = new TessBaseAPI();
		 * 
		 * if (instance.Init("C:\\Users\\Mahi\\Selenium\\Automation\\tessdata", "eng")
		 * != 0) { System.out.println("unable load the data"); }
		 * 
		 * PIX image = lept.pixRead("C:\\Users\\Mahi\\Selenium\\Automation\\img.png");
		 * 
		 * instance.SetImage(image);
		 * 
		 * BytePointer bypePointer = instance.GetUTF8Text();
		 * 
		 * String output = bypePointer.getString(); output=output.replaceAll("\\s", "");
		 * 
		 * System.out.println("text is:" + output);
		 * 
		 * String[] a=output.split("\\+"); String b=a[0]; String c=a[1];
		 * 
		 * int d=Integer.parseInt(b); int e=Integer.parseInt(c); int f=d+e;
		 * 
		 * String answer=Integer.toString(f);
		 * 
		 * System.out.println(answer); WebElement
		 * validNo=driver.findElement(enterValidNumber); validNo.click();
		 * validNo.clear(); validNo.sendKeys(answer,Keys.TAB);
		 */
		/*
		 * File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE); //
		 * Now you can do whatever you need to do with it, for example copy somewhere
		 * FileUtils.copyFile(scrFile, new
		 * File("C:\\Users\\Mahi\\Selenium\\Automation\\screenshot.png"));
		 * 
		 * final BufferedImage source = ImageIO.read(new
		 * File("C:\\Users\\Mahi\\Selenium\\Automation\\screenshot.png"));
		 * 
		 * ImageIO.write(source.getSubimage(285, 467, 40, 40), "png", new
		 * File("C:\\Users\\Mahi\\Selenium\\Automation\\new.png"));
		 */
		
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,200)", "");

		
		WebElement ele = driver.findElement(securityImg);

		// Get entire page screenshot
		File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		BufferedImage  fullImg = ImageIO.read(screenshot);

		

		// Crop the entire page screenshot to get only element screenshot
		BufferedImage eleScreenshot= fullImg.getSubimage(1028, 600,
		    117, 46);
		ImageIO.write(eleScreenshot, "png", screenshot);

		File screenshotLocation = new File(System.getProperty("user.dir")+"\\done.png");
		FileUtils.copyFile(screenshot, screenshotLocation);
		
		 TessBaseAPI instance = new TessBaseAPI();
		 
		  if (instance.Init(System.getProperty("user.dir")+"\\tessdata", "eng")
		  != 0) { System.out.println("unable load the data"); }
		  
		  PIX image = lept.pixRead(System.getProperty("user.dir")+"\\done.png");
		  
		  instance.SetImage(image);
		  
		  BytePointer bypePointer = instance.GetUTF8Text();
		  
		  String output = bypePointer.getString(); output=output.replaceAll("\\s", "");
		  
		  System.out.println("text is:" + output);
		  
		  String[] a=output.split("\\+"); String b=a[0]; String c=a[1];
		  
		  int d=Integer.parseInt(b); int e=Integer.parseInt(c); int f=d+e;
		  
		  String answer=Integer.toString(f);
		  
		  System.out.println(answer); WebElement
		  validNo=driver.findElement(enterValidNumber); validNo.click();
		  validNo.clear(); validNo.sendKeys(answer,Keys.TAB);
		 

	}
	
	public void clickOnJoinWithEmail() {

		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(joinWithEmail))).click();

	}
	
	public void clickOnFacebookLink() {

		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(facebookLink))).click();

	}
	
	public void enterFacebookEmail(String Email) {
		
		Set handles = driver.getWindowHandles();
		 
		 String firstWinHandle = driver.getWindowHandle(); handles.remove(firstWinHandle);
		 
		 String winHandle=(String) handles.iterator().next();
		 
		 if (winHandle!=firstWinHandle){
		 
		 //To retrieve the handle of second window, extracting the handle which does not match to first window handle
		 
		 String secondWinHandle=winHandle; //Storing handle of second window handle
		 
		//Switch control to new window
		 
		 driver.switchTo().window(secondWinHandle);
		 }

		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(facebookEmail))).sendKeys(Email);

	}
	
	public void enterFacebookPassword(String password) {

		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(facebookPass))).sendKeys(password);

	}
	
	public void clickOnLogin() {

		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(facebookLogin))).click();

	}
	
	public void clickOnClose() {

		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(close))).click();

	}

}
