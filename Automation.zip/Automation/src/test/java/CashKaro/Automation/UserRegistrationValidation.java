package CashKaro.Automation;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import cashKaroPages.LoginPage;

public class UserRegistrationValidation {

	WebDriver driver;
	LoginPage login;

	@BeforeTest
	@Parameters("browser")
	public void setup(String browser) throws Exception {

		if (browser.equalsIgnoreCase("chrome")) {

			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir")+"\\lib\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://cashkaro.iamsavings.co.uk/");

		}

		else {

			throw new Exception("Browser is not correct");

		}

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test(priority=1)

	public void freeLoginManual() throws InterruptedException, IOException {

		login = new LoginPage(driver);

		login.clickOnJoinFree();

		login.enterName("mahe");

		login.enterEmail("ancb@gmai.com");
		
		login.enterPassword("nmfnf@334");

		login.enterMobile("9876543210");

		login.securityImg();
	
		login.clickOnJoinWithEmail();
		
		login.clickOnClose();
		
		Thread.sleep(2000);

	}
	
	@Test(priority=2)
	
	public void facebookLogin() throws InterruptedException {
		
		login = new LoginPage(driver);	
		
		login.clickOnJoinFree();
		
		login.clickOnFacebookLink();
		
		login.enterFacebookEmail("parvath@ga.com");
		
		login.enterFacebookPassword("vhjghjgjh");
		
		login.clickOnLogin();
		
	}

}
